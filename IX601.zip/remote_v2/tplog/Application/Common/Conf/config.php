<?php
return array(
	//'配置项'=>'配置值'
	'MODULE_ALLOW_LIST'      =>  array('Home','Admin'),
	// 'TMPL_DENY_PHP'         =>  true, // 默认模板引擎是否禁用PHP原生代码

	/* 数据库设置 */
    'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  '127.0.0.1', // 服务器地址
    'DB_NAME'               =>  'terminal',          // 数据库名
    'DB_USER'               =>  'root',      // 用户名
    'DB_PWD'                =>  '123456',          // 密码
    'DB_PORT'               =>  '3306',        // 端口

);