<?php
/**
 * Created by PhpStorm.
 * User: Why
 * Date: 2017-02-15
 * Time: 19:12
 */
namespace Home\Model;
use Think\Model;

class server_opera_logModel extends Model{
    
}