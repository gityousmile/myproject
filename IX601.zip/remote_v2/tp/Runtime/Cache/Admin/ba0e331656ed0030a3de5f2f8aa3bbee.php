<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>文本测试</title>
</head>
<body>
<?php echo ($_SERVER['PATH']); ?>
<?php echo ($_GET['id']); ?>
</body>
</html>