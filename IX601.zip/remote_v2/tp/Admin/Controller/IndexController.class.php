<?php
/**
 * Created by PhpStorm.
 * User: Why
 * Date: 2017-02-15
 * Time: 13:57
 */
namespace Admin\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        echo "这是Admin分组下的Index控制器中的index方法";
    }
}