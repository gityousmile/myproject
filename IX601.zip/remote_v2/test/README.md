# Sample
Just open index.html at current folder in your favorite browser. Or try it by clicking [link](http://rawgit.com/wangpin34/vue-scroll/2.0-compatible/samples/standlone/index.html)


