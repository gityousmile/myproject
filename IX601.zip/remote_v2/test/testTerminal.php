<?php
 	header("Content-Type:text/html; charset=utf-8");
	echo '
  		{"status": "success", 
  		"msg": "成功  ",
  		"code": "1"  
		}';
?>