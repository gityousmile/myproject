<?php

	print_r($_POST['tdata']);
?>